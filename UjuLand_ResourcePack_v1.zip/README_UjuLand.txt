UjuLand Resource Pack v1

Minecraft/Paper 1.21.11 기준 테스트용 리소스팩입니다.

구성:
- pack.mcmeta
- pack.png
- assets/minecraft/textures/gui/title/mojangstudios.png

서버 적용 순서:
1. 이 ZIP 파일을 GitHub Releases 또는 웹공간에 업로드
2. 다운로드 URL 복사
3. Windows에서 SHA1 생성:
   certutil -hashfile UjuLand_ResourcePack_v1.zip SHA1
4. server.properties 설정:
   resource-pack=다운로드URL
   resource-pack-sha1=SHA1값
   require-resource-pack=true

주의:
1.21.x에서는 MOJANG 로고 경로가 버전에 따라 다를 수 있어 실제 접속 테스트가 필요합니다.
